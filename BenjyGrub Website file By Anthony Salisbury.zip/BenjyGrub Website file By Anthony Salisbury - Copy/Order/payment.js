function conPayment() {
    alert("Thank you for shopping at BenjyGrub!");
}